package com.example.app_trial.resquestApi;

public interface VollyCallBack {
    void onSucess(String response);
    void onfailer(String response);

}
