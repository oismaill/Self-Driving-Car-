package com.example.app_trial.resquestApi;

import java.util.Map;

public class reqApi {

    public void select(final VollyCallBack vollyCallBack,String table, Map<String, String> map){

        // onRespone Volly
        vollyCallBack.onSucess("");

        // onError
        vollyCallBack.onfailer("");

    }

}
