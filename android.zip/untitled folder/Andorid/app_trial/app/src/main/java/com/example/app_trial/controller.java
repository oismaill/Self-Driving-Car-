package com.example.app_trial;

import java.util.Map;

public class controller {

    model m = new model();

    public void getUser(String email, String pass, final model_controller mc){

        Map<String, String> con = null;
        con.put("email_same_as_database", email);
        con.put("pass_same_as_database", pass);

        m.selectUser(con, new model_controller() {
            @Override
            public void onSucess(String response) { // User user
                mc.onSucess(response);
            }

            @Override
            public void onfailer(String response) {
                mc.onfailer(response);
            }
        });

    }

}
