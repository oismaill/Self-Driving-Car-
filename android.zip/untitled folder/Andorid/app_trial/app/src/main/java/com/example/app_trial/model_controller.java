package com.example.app_trial;

public interface model_controller {

    void onSucess(String response);
    void onfailer(String response);

}
