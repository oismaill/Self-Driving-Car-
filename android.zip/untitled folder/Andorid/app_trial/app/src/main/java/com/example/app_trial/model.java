package com.example.app_trial;

import com.example.app_trial.resquestApi.VollyCallBack;
import com.example.app_trial.resquestApi.reqApi;

import java.util.Map;

public class model {

    reqApi api = new reqApi();

    public void selectUser(Map<String, String> con, final model_controller mc){

        api.select(new VollyCallBack() {
            @Override
            public void onSucess(String response) {

                // response >> jsonObject jo >> User object

                // if(jo.getBoolean("errror")){mc.onfailer(jo.getString("message"));}


                mc.onSucess(response); // User obj
            }

            @Override
            public void onfailer(String response) {
                mc.onfailer(response);
            }
        }, "table", con);

    }


}
