package com.example.ipingpong.controllers;

import android.content.Context;

import com.example.ipingpong.controllers.CallBacks.LoginCallBack;
import com.example.ipingpong.models.UserModel;
import com.example.ipingpong.shared.datasource.local.SharedPrefManager;
import com.example.ipingpong.shared.entities.User;
import com.example.ipingpong.shared.entities.UserType;

import java.util.HashMap;

public class LoginController {
    private UserModel userModel;
    private Context context;

    public LoginController(Context context) {
        this.context = context;
        this.userModel = new UserModel(context);
    }

    public void login(String email, String password, final LoginCallBack loginCallBack) {

        HashMap<String, String> conditions = new HashMap<String, String>();
        conditions.put("email", email);
        conditions.put("password", password);
        conditions.put("isdeleted", String.valueOf(0));

        userModel.login(conditions, new LoginCallBack() {
            @Override
            public void onLoginSuccess(User user, UserType userType) {

                //storing the user in shared preferences
                SharedPrefManager.getInstance(context).userLogin(user);
                loginCallBack.onLoginSuccess(user, userType);
            }

            @Override
            public void onLoginFailure(String reason) {

                loginCallBack.onLoginFailure(reason);
            }
        });
    }

    public Boolean checkEmail(String email) {



        return true;
    }

    public Boolean checkPassword(String password) {


        return true;
    }
}
