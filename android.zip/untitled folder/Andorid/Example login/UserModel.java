package com.example.ipingpong.models;

import android.content.Context;

import com.example.ipingpong.controllers.CallBacks.DeleteUserCallBacks;
import com.example.ipingpong.controllers.CallBacks.GetSingleAddress;
import com.example.ipingpong.controllers.CallBacks.LoginCallBack;
import com.example.ipingpong.controllers.CallBacks.SelectClubCallBack;
import com.example.ipingpong.controllers.CallBacks.SelectUserCallBack;
import com.example.ipingpong.controllers.CallBacks.SelectUsersByUserTypesCallBack;
import com.example.ipingpong.shared.datasource.Constants;
import com.example.ipingpong.shared.datasource.remote.RequestApi;
import com.example.ipingpong.shared.datasource.remote.VolleyCallBack;
import com.example.ipingpong.shared.entities.Address;
import com.example.ipingpong.shared.entities.Club;
import com.example.ipingpong.shared.entities.User;
import com.example.ipingpong.shared.entities.UserType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class UserModel {
    private RequestApi requestApi;
    private ClubModel clubModel;
    private AddressModel addressModel;

    public UserModel(Context context) {
        this.requestApi = new RequestApi(context);
        this.clubModel = new ClubModel(context);
        this.addressModel = new AddressModel(context);
    }

    public void login(HashMap<String, String> conditions, final LoginCallBack loginCallBack) {

        requestApi.selectApi(new VolleyCallBack() {
            @Override
            public void onError(Throwable throwable) {
                loginCallBack.onLoginFailure(throwable.getMessage());
            }

            @Override
            public void onSuccess(String result) {

                try {

                    JSONObject obj = new JSONObject(result);

                    if (obj.getBoolean("error")) {
                        loginCallBack.onLoginFailure(obj.getString("message"));
                    }
                    else {

                        String res = obj.getString(Constants.table_name_users).replace("[", "");
                        String res2 = res.replace("]", "");

                        final JSONObject userJson = new JSONObject(res2);


                        //filling a new user object info
                        //userJson.getInt("addressID"),
                        //userJson.getInt("clubID"),

                        final User user = new User();
                        user.setId(userJson.getInt("id"));
                        user.setUser_name(userJson.getString("user_name"));
                        user.setEmail(userJson.getString("email"));
                        user.setPassword(userJson.getString("password"));
                        user.setGender(userJson.getString("gender"));
                        user.setPhoneNumber(userJson.getString("phoneNumber"));
                        user.setBirthdate(userJson.getString("birthdate"));

                        UserType userType;

                        int userTypeId = userJson.getInt("usertypeID");

                        if (userTypeId == UserType.COACH.getValue()) {
                            userType = UserType.COACH;
                        } else if(userTypeId == UserType.PLAYER.getValue()){
                            userType = UserType.PLAYER;
                        } else if(userTypeId == UserType.ClubManager.getValue()){
                            userType = UserType.ClubManager;
                        } else{
                            userType = UserType.Admin;
                        }

                        clubModel.getClub(String.valueOf(userJson.getInt("clubID")), new SelectClubCallBack() {
                            @Override
                            public void onSuccess(Club club) {
                                user.setClub(club);

                                try {
                                    addressModel.getSingleAddress(String.valueOf(userJson.getInt("addressID")), new GetSingleAddress() {
                                        @Override
                                        public void onSuccess(Address address) {
                                            user.setAddress(address);
                                        }

                                        @Override
                                        public void onFailure(String reason) {
                                            loginCallBack.onLoginFailure(reason);
                                        }
                                    });
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }

                            @Override
                            public void onFailure(String reason) {
                                loginCallBack.onLoginFailure(reason);
                            }
                        });

                        loginCallBack.onLoginSuccess(user, userType);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, Constants.table_name_users, conditions);
    }

    public void getUser(String userID, final SelectUserCallBack selectUserCallBack){

        HashMap<String, String> conditions = new HashMap<String, String>();
        conditions.put("id", userID);

        requestApi.selectApi(new VolleyCallBack() {
            @Override
            public void onError(Throwable throwable) {
                selectUserCallBack.onFailure(throwable.getMessage());
            }

            @Override
            public void onSuccess(String result) {

                try {

                    //System.out.println(result);

                    JSONObject obj = new JSONObject(result);

                    if (obj.getBoolean("error")) {
                        selectUserCallBack.onFailure(obj.getString("message"));
                    }
                    else {

                        String res = obj.getString(Constants.table_name_users).replace("[", "");
                        String res2 = res.replace("]", "");

                        final JSONObject userJson = new JSONObject(res2);

                        final User user = new User();
                        user.setId(userJson.getInt("id"));
                        user.setUser_name(userJson.getString("user_name"));
                        user.setEmail(userJson.getString("email"));
                        user.setPassword(userJson.getString("password"));
                        user.setGender(userJson.getString("gender"));
                        user.setPhoneNumber(userJson.getString("phoneNumber"));
                        user.setBirthdate(userJson.getString("birthdate"));

                        int userTypeId = userJson.getInt("usertypeID");

                        if (userTypeId == UserType.COACH.getValue()) {
                            user.setUserType(UserType.COACH);
                        } else if(userTypeId == UserType.PLAYER.getValue()){
                            user.setUserType(UserType.PLAYER);
                        } else if(userTypeId == UserType.ClubManager.getValue()){
                            user.setUserType(UserType.ClubManager);
                        } else{
                            user.setUserType(UserType.Admin);
                        }

                        clubModel.getClub(String.valueOf(userJson.getInt("clubID")), new SelectClubCallBack() {
                            @Override
                            public void onSuccess(Club club) {
                                user.setClub(club);

                                try {
                                    addressModel.getSingleAddress(String.valueOf(userJson.getInt("addressID")), new GetSingleAddress() {
                                        @Override
                                        public void onSuccess(Address address) {
                                            user.setAddress(address);
                                        }

                                        @Override
                                        public void onFailure(String reason) {
                                            selectUserCallBack.onFailure(reason);
                                        }
                                    });
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }

                            @Override
                            public void onFailure(String reason) {
                                selectUserCallBack.onFailure(reason);
                            }
                        });



                        selectUserCallBack.onSuccess(user);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, Constants.table_name_users, conditions);



    }

    public void deleteUser(String userID, final DeleteUserCallBacks deleteUserCallBacks){


        HashMap<String, String> conditions = new HashMap<String, String>();
        conditions.put("id", userID);

        requestApi.deleteApi(new VolleyCallBack() {
            @Override
            public void onError(Throwable throwable) {
                deleteUserCallBacks.onFailure(throwable.getMessage());
            }

            @Override
            public void onSuccess(String result) {

                try {

                    //System.out.println(result);

                    JSONObject obj = new JSONObject(result);

                    if (obj.getBoolean("error")) {
                        deleteUserCallBacks.onFailure(obj.getString("message"));
                    }
                    else {

                        deleteUserCallBacks.onSuccess(obj.getString("message"));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, Constants.table_name_users, conditions);
    }

    public void getUsers(HashMap<String, String> conditions, final SelectUsersByUserTypesCallBack selectUsersByUserTypesCallBack){

        requestApi.selectApi(new VolleyCallBack() {
            @Override
            public void onSuccess(String result) {

                //System.out.println(result);

                try {
                    JSONObject obj = new JSONObject(result);
                    final ArrayList<User> users = new ArrayList<>();

                    if (obj.getBoolean("error")) {
                        selectUsersByUserTypesCallBack.onFailure(obj.getString("message"));
                    }
                    else{

                        JSONArray jsonArray = obj.getJSONArray(Constants.table_name_users);
                        int x = 0;
                        while (x < jsonArray.length()){

                            final JSONObject jsonObject = (JSONObject) jsonArray.get(x);

                            System.out.println(jsonArray.length());

                            final User user = new User();
                            user.setId(jsonObject.getInt("id"));
                            user.setUser_name(jsonObject.getString("user_name"));
                            user.setEmail(jsonObject.getString("email"));
                            user.setPassword(jsonObject.getString("password"));
                            user.setGender(jsonObject.getString("gender"));
                            user.setPhoneNumber(jsonObject.getString("phoneNumber"));
                            user.setBirthdate(jsonObject.getString("birthdate"));

                            int userTypeId = jsonObject.getInt("usertypeID");

                            if (userTypeId == UserType.COACH.getValue()) {
                                user.setUserType(UserType.COACH);
                            } else if(userTypeId == UserType.PLAYER.getValue()){
                                user.setUserType(UserType.PLAYER);
                            } else if(userTypeId == UserType.ClubManager.getValue()){
                                user.setUserType(UserType.ClubManager);
                            } else{
                                user.setUserType(UserType.Admin);
                            }

                            clubModel.getClub(String.valueOf(jsonObject.getInt("clubID")), new SelectClubCallBack() {
                                @Override
                                public void onSuccess(Club club) {
                                    user.setClub(club);

                                    try {
                                        addressModel.getSingleAddress(String.valueOf(jsonObject.getInt("addressID")), new GetSingleAddress() {
                                            @Override
                                            public void onSuccess(Address address) {
                                                user.setAddress(address);
                                                users.add(user);
                                                selectUsersByUserTypesCallBack.onSuccess(users);
                                            }

                                            @Override
                                            public void onFailure(String reason) {
                                                selectUsersByUserTypesCallBack.onFailure(reason);
                                            }
                                        });
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }

                                @Override
                                public void onFailure(String reason) {
                                    selectUsersByUserTypesCallBack.onFailure(reason);
                                }
                            });




                            x++;
                        }





                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onError(Throwable throwable) {
                selectUsersByUserTypesCallBack.onFailure(throwable.getMessage());
            }
        }, Constants.table_name_users, conditions);

    }

}
