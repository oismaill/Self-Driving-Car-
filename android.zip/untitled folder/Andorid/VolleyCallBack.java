package com.example.ipingpong.shared.datasource.remote;

public interface VolleyCallBack {
    void onSuccess(String result);
    void onError(Throwable throwable);
}
