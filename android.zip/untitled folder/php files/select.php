<?php
    
    require_once 'database.php';
    
    $table_name = $_POST["table"];
    $received_data = $_POST["conditions"];
    $new_array = json_decode($received_data,true);

    $db = database::getInstance();
    $result = database::select($table_name, $new_array, null);
    
    if($result != null) {
        $response["error"] = false;
        $response["message"] = 'Select successfully';
        $response[$table_name] = $result;
    }
    else {
        $response['error'] = true;   
         if(database::error_msg() == "Error description: "){
            $response['message'] = 'No Data Avaliable';
        }else{
            $response['message'] = database::error_msg();
        }
    }

    echo json_encode($response);

?>
