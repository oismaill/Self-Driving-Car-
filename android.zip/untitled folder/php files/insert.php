<?php
    
    require_once 'database.php';
    
    $table = $_POST["table"];
    $data = $_POST["data"];
    
    $db = database::getInstance();
    $return_insert = database::insert($table, $data);
    
    if($return_insert === true) {
        $response["error"] = false;
        $response["message"] = 'Insert successfully';
    }
    else {
        $response['error'] = true;
        $response['message'] = database::error_msg();
    }
    
     echo json_encode($response);

?>
