<?php
    
    require_once 'database.php';

    $table = $_POST["table"];
    $data = $_POST["data"];
    $conditions = $_POST["conditions"];

    $db = database::getInstance();
    $return_update = database::update($table, $data, $conditions);
    
    if($return_update === true) {
        $response["error"] = false;
        $response["message"] = 'Update successfully';
    }
    else {
        $response['error'] = true;
        $response['message'] = database::error_msg();
    }
    
     echo json_encode($response);

?>
